﻿namespace Ex04.Menus.Test
{
    public static class Program
    {
        public static void Main()
        {
            MockMenus mockMenus = new MockMenus();
            mockMenus.Show();
        }
    }
}