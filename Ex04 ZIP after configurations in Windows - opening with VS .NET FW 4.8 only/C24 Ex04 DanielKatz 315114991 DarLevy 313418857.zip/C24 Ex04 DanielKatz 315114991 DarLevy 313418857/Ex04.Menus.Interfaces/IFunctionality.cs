namespace Ex04.Menus.Interfaces
{
    public interface IFunctionality
    {
        void Execute();
    }
}
